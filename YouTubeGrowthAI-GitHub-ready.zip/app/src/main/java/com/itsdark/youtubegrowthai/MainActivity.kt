package com.itsdark.youtubegrowthai

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val input = findViewById<EditText>(R.id.topicInput)
        val button = findViewById<Button>(R.id.generateButton)
        val result = findViewById<TextView>(R.id.resultText)

        button.setOnClickListener {
            val topic = input.text.toString().trim()
            if (topic.isEmpty()) {
                input.error = "Enter a topic"
                return@setOnClickListener
            }

            result.text = """
YOUTUBE GROWTH AI

TITLE IDEAS
1. $topic 🔥
2. $topic | The Ultimate Moment 😱
3. You Won't Believe This $topic!
4. This $topic Moment Was INSANE 🤯
5. $topic Edit ❤️‍🔥

DESCRIPTION
Watch this amazing $topic moment!
More anime Shorts content coming soon.

HOOK
Wait until you see what happens...

HASHTAGS
#shorts #anime #animeedit #dbs #goku #vegeta

KEYWORDS
$topic, anime edit, anime shorts, dragon ball, viral shorts

THUMBNAIL TEXT
INSANE MOMENT 🔥

GROWTH TIP
Keep the opening seconds strong and make the title match the actual video.
            """.trimIndent()
        }
    }
}
