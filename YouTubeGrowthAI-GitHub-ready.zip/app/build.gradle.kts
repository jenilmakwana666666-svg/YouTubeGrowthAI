plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.itsdark.youtubegrowthai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.itsdark.youtubegrowthai"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
}
