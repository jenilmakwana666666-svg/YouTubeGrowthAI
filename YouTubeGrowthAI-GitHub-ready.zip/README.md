# YouTube Growth AI

Lightweight Android starter project for a YouTube Shorts content generator.

Current version:
- Topic input
- Title ideas
- Description
- Hook
- Hashtags
- Keywords
- Thumbnail text
- Growth tip

The current generator is local/template based. The next stage is to connect a small quantized GGUF model through llama.cpp for real offline AI generation.

## GitHub build
Push the project to GitHub, open Actions, run Build YouTube Growth AI, then download the APK artifact.
